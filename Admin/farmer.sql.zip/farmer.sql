-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 11, 2012 at 04:21 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `farmer`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `aid` int(11) NOT NULL AUTO_INCREMENT,
  `a_login` varchar(20) NOT NULL,
  `a_password` varchar(20) NOT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `a_login`, `a_password`) VALUES
(1, 'mahesh', '123');

-- --------------------------------------------------------

--
-- Table structure for table `dist_mngt`
--

CREATE TABLE IF NOT EXISTS `dist_mngt` (
  `did` int(11) NOT NULL AUTO_INCREMENT,
  `district` varchar(20) NOT NULL,
  PRIMARY KEY (`did`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `dist_mngt`
--

INSERT INTO `dist_mngt` (`did`, `district`) VALUES
(6, 'Talaja'),
(4, 'bharuch'),
(7, 'Botad');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `f_id` varchar(20) NOT NULL,
  `serv_no` varchar(35) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `village` varchar(15) NOT NULL,
  `comment` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `f_id`, `serv_no`, `address`, `phone`, `village`, `comment`) VALUES
(1, 'mj', '   NMN M M', '45646', '554564', 'NKNJK', 'mahesbuusbassbiyb \r\n'),
(2, 'raj003', '7', 'opposite temple of ramapir,', '9998344078', 'Savani', 'bov mast service chhe baki');

-- --------------------------------------------------------

--
-- Table structure for table `god_mngt`
--

CREATE TABLE IF NOT EXISTS `god_mngt` (
  `gid` int(11) NOT NULL AUTO_INCREMENT,
  `godown_name` varchar(20) NOT NULL,
  `stock` varchar(10) NOT NULL,
  PRIMARY KEY (`gid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `god_mngt`
--

INSERT INTO `god_mngt` (`gid`, `godown_name`, `stock`) VALUES
(5, 'G5', '200');

-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--

CREATE TABLE IF NOT EXISTS `inquiry` (
  `iid` int(11) NOT NULL AUTO_INCREMENT,
  `f_name` varchar(20) NOT NULL,
  `c_num` varchar(13) NOT NULL,
  `d_name` varchar(20) NOT NULL,
  `t_name` varchar(20) NOT NULL,
  `v_name` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `serv_no` varchar(20) NOT NULL,
  `comments` varchar(255) NOT NULL,
  PRIMARY KEY (`iid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `inquiry`
--

INSERT INTO `inquiry` (`iid`, `f_name`, `c_num`, `d_name`, `t_name`, `v_name`, `address`, `serv_no`, `comments`) VALUES
(5, 'maheesh', 'ubu', 'Select yuor District', 'uihuih', 'uh', 'uhuh', 'u', 'jh'),
(4, 'dhan', 'uhuibiuh', 'Select yuor District', 'kjj', 'kjbb', 'ijbuibu', 'bub', 'hello how ru?\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `my_order`
--

CREATE TABLE IF NOT EXISTS `my_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crop` varchar(20) NOT NULL,
  `pesti` varchar(20) NOT NULL,
  `amt_crop` int(10) NOT NULL,
  `amt_pest` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `my_order`
--

INSERT INTO `my_order` (`id`, `crop`, `pesti`, `amt_crop`, `amt_pest`) VALUES
(1, 'Wheet', '11', 0, 12),
(2, 'Bajari', '11', 0, 10),
(3, 'Cotton', 'Dioran', 12, 13),
(4, 'Sugarcan', 'Oxydiogen', 14, 14);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `nid` int(11) NOT NULL AUTO_INCREMENT,
  `tittle` varchar(20) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`nid`, `tittle`, `description`) VALUES
(1, 'great performance', 'very good...now u can also try this service from your home '),
(6, 'Krushi mela 2012', 'Our Government is going to conduct a krushimela for our farmer brothers at ahmedabad city ');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `f_name` text NOT NULL,
  `f_id` varchar(20) NOT NULL,
  `password` varchar(15) NOT NULL,
  `age` varchar(3) NOT NULL,
  `c_num` varchar(13) NOT NULL,
  `address` varchar(30) NOT NULL,
  `d_name` varchar(15) NOT NULL,
  `t_name` varchar(15) NOT NULL,
  `v_name` varchar(15) NOT NULL,
  `y_income` varchar(10) NOT NULL,
  `s_num` varchar(10) NOT NULL,
  `area_of_serv_no` varchar(10) NOT NULL,
  `t_land` varchar(20) NOT NULL,
  `w_irrigation` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `f_name`, `f_id`, `password`, `age`, `c_num`, `address`, `d_name`, `t_name`, `v_name`, `y_income`, `s_num`, `area_of_serv_no`, `t_land`, `w_irrigation`) VALUES
(6, 'nathiyo-lala-gohil', 'hakudi', 'mahesh', '30', '9998999899', 'metrocity', 'Ahmedabad', 'Junagarh', 'Savani', 'More than ', 'E1102012', 'C203', 'Desert soil', 'Spray Irrigation');

-- --------------------------------------------------------

--
-- Table structure for table `s_prod`
--

CREATE TABLE IF NOT EXISTS `s_prod` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `m_pro` varchar(20) NOT NULL,
  `sp_name` varchar(20) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `s_prod`
--


-- --------------------------------------------------------

--
-- Table structure for table `transfer`
--

CREATE TABLE IF NOT EXISTS `transfer` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `main_godown` varchar(20) NOT NULL,
  `to_godown` varchar(15) NOT NULL,
  `prod` varchar(15) NOT NULL,
  `s_prod` varchar(12) NOT NULL,
  `kg` int(2) NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `transfer`
--

INSERT INTO `transfer` (`tid`, `main_godown`, `to_godown`, `prod`, `s_prod`, `kg`) VALUES
(1, 'Godown1', 'Godown1', 'Crop', 'Bajari', 50);

-- --------------------------------------------------------

--
-- Table structure for table `village_mngt`
--

CREATE TABLE IF NOT EXISTS `village_mngt` (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `village` varchar(20) NOT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `village_mngt`
--

INSERT INTO `village_mngt` (`vid`, `village`) VALUES
(3, 'varal'),
(4, 'pranchi'),
(5, 'una'),
(7, 'Bagdana');
